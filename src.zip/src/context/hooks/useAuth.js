import { useState, useEffect } from 'react';
import { useHistory } from "react-router-dom";
import api from '../../Services/api';


export default function useAuth() {
  const [authenticated, setAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const history = useHistory();
  
  useEffect(() => {
    const token = localStorage.getItem('token');

    if (token) {
      api.defaults.headers.Authorization = `Bearer ${JSON.parse(token)}`;
      setAuthenticated(true);
    }

    setLoading(false);
  }, []);
  
  async function handleLogin(e) {
    e.preventDefault();
    const { data } = await api.post('login', {}, {
        auth: {
          username: 'root',
          password: 'password'
        }
      })

    localStorage.setItem('token', JSON.stringify(data));
    api.defaults.headers.Authorization = `Bearer ${data}`;
    setAuthenticated(true);
    history.push('/aopa');
  }

  function handleLogout() {
    setAuthenticated(false);
    localStorage.removeItem('token');
    api.defaults.headers.Authorization = undefined;
    history.push('/login');
  }
  
  return { authenticated, loading, handleLogin, handleLogout };
}