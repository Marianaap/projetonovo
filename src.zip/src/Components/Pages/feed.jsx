

import React, {  useState, useContext } from "react";
import { Context } from '../../context/AuthContext';
import api from '../../Services/api'
import '../static/style.css'
import history from '../../history'
import Header from '../header'
import Footer from '../footer'
import PostHeader from "../postheader";
import PostFooter from "../postfooter";

function Feed() {

  return (
    <div id="App">
      <div className="fixed-bars">
        <Header className="header-comp"></Header>
        <Footer className="footer-comp"></Footer>
      </div>
      <div className="feed-page">
        <div className="feed-content">
          <PostHeader></PostHeader>
          <img className="post" src="/placeholder.svg"></img>
          <PostFooter></PostFooter>
          <PostHeader></PostHeader>
          <img className="post" src="/placeholder.svg"></img>
          <PostFooter></PostFooter>
          <PostHeader></PostHeader>
          <img className="post" src="/placeholder.svg"></img>
          <PostFooter></PostFooter>
          <PostHeader></PostHeader>
          <img className="post" src="/placeholder.svg"></img>
          <PostFooter></PostFooter>
          <PostHeader></PostHeader>
          <img className="post" src="/placeholder.svg"></img>
          <PostFooter></PostFooter>
        </div>
      </div>      
    </div>
  );
}

export default Feed;
