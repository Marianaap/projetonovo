import React, {  useState, useContext } from "react";
import { useHistory } from "react-router-dom";


function Header(props) {
  const history = useHistory();
  function goToUser(){
    history.push("/index")
  }
 
  if (props.config =="Menu"){
    return (
      <div className="header-comp-div">
        <div className="feed-header">
            <a className="username" onClick={goToUser}> Menu </a>
            <div className="user-div">
            <img className="userpic" src="/Vector.svg"></img>
           
       
        </div>
        </div>
      </div>
    );
  }
  else if (props.config == "Feed")
  return (
    <div className="header-comp-div">
      <div className="feed-header">
        <img className="logomarca" src="/logomarca.svg"></img>
        <div className="user-div">
            <a className="username" onClick={goToUser}> USERNAME </a>
            <img className="userpic" src="/userpic.svg"></img>

        </div>
      </div>
    </div>
  );
}

export default Header;


