import React, {  useState, useContext } from "react";

function Footer() {

  return (
    <div className="footer-comp-div">
      <div className="feed-footer">
        <img className="item-footer" src="/menu.svg"></img>
        <img className="item-footer" src="/explore.svg"></img>
        <img className="item-footer" src="/home.svg"></img>
        <img className="item-footer" src="/feed.svg"></img>
        <img className="item-footer" src="/social.svg"></img>
      </div>      
    </div>
  );
}

export default Footer;
